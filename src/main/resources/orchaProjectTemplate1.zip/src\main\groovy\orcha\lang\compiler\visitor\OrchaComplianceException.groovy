package orcha.lang.compiler.visitor

class OrchaComplianceException extends Exception{

	public OrchaComplianceException() {
		super();
	}

	public OrchaComplianceException(String message) {
		super(message);
	}

	
}
