package service.order

import groovy.transform.ToString;

@ToString
class SpecificOrder {
	
	int number
	String product
	
}

