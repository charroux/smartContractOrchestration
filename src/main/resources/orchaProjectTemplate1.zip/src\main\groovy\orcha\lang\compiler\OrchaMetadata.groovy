package orcha.lang.compiler

class OrchaMetadata {
	
	String title
	String description
	String domain
	String author
	String version

}
