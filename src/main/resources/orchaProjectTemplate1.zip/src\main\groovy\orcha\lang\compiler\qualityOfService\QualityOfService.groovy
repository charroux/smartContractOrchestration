package orcha.lang.compiler.qualityOfServiceimport orcha.lang.compiler.visitor.OrchaCodeParser;
interface QualityOfService {	
		void setQualityOfServiceToInstructions(OrchaCodeParser orchaCodeParser)}
