package orcha.lang.business

public interface BusinessAdapter {

	String adaptOrchaFileToBusiness(String orchaFile)
	
}
