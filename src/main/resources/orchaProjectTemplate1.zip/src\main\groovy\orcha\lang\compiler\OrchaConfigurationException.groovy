package orcha.lang.compiler

class OrchaConfigurationException extends Exception{

	public OrchaConfigurationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrchaConfigurationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
