package orcha.lang.compiler

class OrchaCompilationException extends Exception{

	public OrchaCompilationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrchaCompilationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
