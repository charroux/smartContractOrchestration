package orcha.lang.programlifecycle

import org.springframework.batch.core.BatchStatus;

enum ProgramStatus {
	
	COMPLETED, STARTING, STARTED, STOPPING, STOPPED, FAILED, ABANDONED, UNKNOWN;

	
}


